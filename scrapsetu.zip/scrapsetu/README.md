# ScrapSetu

Open-source platform jo **scrap collectors (kabadiwale) ko recyclers se jodta hai** aur har deal ka digital record banata hai.

> Hack for Social Cause (MY Bharat) ke liye banaya gaya prototype. SDG 8, SDG 9 aur SDG 12 se aligned.

## Problem

India ka scrap sector zyadatar unorganised hai. Collectors ko market rate nahi pata hota, weight/payment ka koi record nahi hota, aur formal pehchaan nahi milti.

## Features

- Recyclers apna **rate per kg** post karte hain; collectors **best rate pehle** dekhte hain
- Collectors scrap ki **listing** (material + weight) banate hain
- Recycler listing khareedta hai; **amount apne aap calculate** hota hai
- Har deal ka **digital record** (weight, rate, amount, UPI reference) dono parties ko milta hai
- Simple Hindi-English web page jisme live rates dikhte hain

## Tech stack

Python 3.10+, Flask, SQLite, plain HTML/JS (koi framework nahi), pytest.

## Setup

```bash
git clone https://github.com/<your-username>/scrapsetu.git
cd scrapsetu

python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python scripts/seed.py           # optional: sample data load karo
flask --app app run --debug      # http://127.0.0.1:5000
```

Database file `scrapsetu.sqlite` pehli baar run par apne aap ban jati hai.
Alag jagah chahiye to `SCRAPSETU_DB=/path/to/file.sqlite` set karo.

## Tests

```bash
pytest -v
```

## API quick reference

| Method | Endpoint | Kaam |
|---|---|---|
| GET | `/api/health` | Server check |
| POST | `/api/users` | User banao (`name`, `role`, `phone`, `city`) |
| GET | `/api/users/<id>` | User dekho |
| POST | `/api/rates` | Recycler rate set kare (`recycler_id`, `material`, `price_per_kg`) |
| GET | `/api/rates?material=&city=` | Latest rates, best price pehle |
| POST | `/api/listings` | Collector scrap list kare (`collector_id`, `material`, `weight_kg`) |
| GET | `/api/listings?city=&status=` | Listings dekho (default: open) |
| POST | `/api/transactions` | Recycler listing khareede (`recycler_id`, `listing_id`, `payment_ref`) |
| GET | `/api/transactions?user_id=` | Kisi user ke saare deals |

Materials: copper, brass, aluminium, iron, steel, plastic, paper.

Example:

```bash
curl -X POST http://127.0.0.1:5000/api/users \
  -H "Content-Type: application/json" \
  -d '{"name":"Ramesh","role":"collector","phone":"9876543210","city":"Rohtak"}'
```

## Project structure

```
app/            Flask app (api.py, db.py, static/index.html)
data/           sample_data.json (illustrative numbers, real rates nahi)
docs/           ARCHITECTURE.md
scripts/        seed.py
tests/          pytest test suite
```

Design details ke liye [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) dekho.

## Current limitations (honest list)

- Authentication / OTP login abhi nahi hai (prototype)
- Payment sirf **record** hota hai (UPI reference text); asli UPI integration nahi
- Photo upload aur map-based nearby matching roadmap me hain
- Sample rates sirf demo ke liye hain

## Roadmap

1. OTP login
2. Real UPI payment integration
3. Photo upload aur Google Maps se nearby buyers
4. Hindi-first mobile app

## License

MIT, [LICENSE](LICENSE) dekho.
