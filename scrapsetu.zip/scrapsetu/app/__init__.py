"""ScrapSetu: scrap collectors ko recyclers se jodne wala open-source platform."""
import os

from flask import Flask

from . import db


def create_app(test_config=None):
    app = Flask(__name__, static_folder="static", static_url_path="/static")
    default_db = os.path.join(os.path.dirname(os.path.dirname(__file__)), "scrapsetu.sqlite")
    app.config["DATABASE"] = os.environ.get("SCRAPSETU_DB", default_db)

    if test_config:
        app.config.update(test_config)

    app.teardown_appcontext(db.close_db)

    with app.app_context():
        db.init_db()

    from .api import bp

    app.register_blueprint(bp)

    @app.get("/")
    def index():
        return app.send_static_file("index.html")

    return app
