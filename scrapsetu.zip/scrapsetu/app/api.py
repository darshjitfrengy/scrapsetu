"""REST API for ScrapSetu."""
import re
import sqlite3

from flask import Blueprint, jsonify, request

from .db import get_db

bp = Blueprint("api", __name__, url_prefix="/api")

MATERIALS = {"copper", "brass", "aluminium", "iron", "steel", "plastic", "paper"}
ROLES = {"collector", "recycler"}
PHONE_RE = re.compile(r"^[6-9]\d{9}$")  # Indian mobile number


def error(message, status=400):
    return jsonify({"error": message}), status


def _number(value):
    """Return value as float if it is a real positive number, else None."""
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def _user(user_id):
    return get_db().execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()


@bp.get("/health")
def health():
    return jsonify({"status": "ok"})


# ---------- Users ----------
@bp.post("/users")
def create_user():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    role = data.get("role")
    phone = str(data.get("phone", "")).strip()
    city = str(data.get("city", "")).strip().title()

    if not name:
        return error("name zaroori hai")
    if role not in ROLES:
        return error("role 'collector' ya 'recycler' hona chahiye")
    if not PHONE_RE.match(phone):
        return error("phone 10 digit ka valid Indian mobile number hona chahiye")
    if not city:
        return error("city zaroori hai")

    db = get_db()
    try:
        cur = db.execute(
            "INSERT INTO users (name, role, phone, city) VALUES (?, ?, ?, ?)",
            (name, role, phone, city),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return error("is phone number se user pehle se hai", 409)
    return jsonify(dict(_user(cur.lastrowid))), 201


@bp.get("/users/<int:user_id>")
def get_user(user_id):
    user = _user(user_id)
    if user is None:
        return error("user nahi mila", 404)
    return jsonify(dict(user))


# ---------- Rates ----------
@bp.post("/rates")
def set_rate():
    data = request.get_json(silent=True) or {}
    recycler = _user(data.get("recycler_id"))
    material = str(data.get("material", "")).lower()
    price = _number(data.get("price_per_kg"))

    if recycler is None or recycler["role"] != "recycler":
        return error("valid recycler_id chahiye", 400)
    if material not in MATERIALS:
        return error("material valid nahi hai: " + ", ".join(sorted(MATERIALS)))
    if price is None:
        return error("price_per_kg 0 se zyada number hona chahiye")

    db = get_db()
    cur = db.execute(
        "INSERT INTO rates (recycler_id, material, price_per_kg, city) VALUES (?, ?, ?, ?)",
        (recycler["id"], material, price, recycler["city"]),
    )
    db.commit()
    row = db.execute("SELECT * FROM rates WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201


@bp.get("/rates")
def list_rates():
    """Latest rate per recycler per material, best price first."""
    material = request.args.get("material", "").lower()
    city = request.args.get("city", "").strip().title()
    sql = """
        SELECT r.recycler_id, u.name AS recycler_name, r.material,
               r.price_per_kg, r.city, r.created_at
        FROM rates r
        JOIN users u ON u.id = r.recycler_id
        WHERE r.id = (
            SELECT MAX(id) FROM rates
            WHERE recycler_id = r.recycler_id AND material = r.material
        )
    """
    params = []
    if material:
        sql += " AND r.material = ?"
        params.append(material)
    if city:
        sql += " AND r.city = ?"
        params.append(city)
    sql += " ORDER BY r.price_per_kg DESC"
    rows = get_db().execute(sql, params).fetchall()
    return jsonify([dict(r) for r in rows])


# ---------- Listings ----------
@bp.post("/listings")
def create_listing():
    data = request.get_json(silent=True) or {}
    collector = _user(data.get("collector_id"))
    material = str(data.get("material", "")).lower()
    weight = _number(data.get("weight_kg"))

    if collector is None or collector["role"] != "collector":
        return error("valid collector_id chahiye")
    if material not in MATERIALS:
        return error("material valid nahi hai: " + ", ".join(sorted(MATERIALS)))
    if weight is None:
        return error("weight_kg 0 se zyada number hona chahiye")

    db = get_db()
    cur = db.execute(
        "INSERT INTO listings (collector_id, material, weight_kg, photo_url, city) "
        "VALUES (?, ?, ?, ?, ?)",
        (collector["id"], material, weight, data.get("photo_url"), collector["city"]),
    )
    db.commit()
    row = db.execute("SELECT * FROM listings WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201


@bp.get("/listings")
def list_listings():
    city = request.args.get("city", "").strip().title()
    status = request.args.get("status", "open")
    sql = "SELECT * FROM listings WHERE status = ?"
    params = [status]
    if city:
        sql += " AND city = ?"
        params.append(city)
    sql += " ORDER BY id DESC"
    rows = get_db().execute(sql, params).fetchall()
    return jsonify([dict(r) for r in rows])


# ---------- Transactions ----------
@bp.post("/transactions")
def create_transaction():
    """A recycler buys an open listing at their own latest posted rate."""
    data = request.get_json(silent=True) or {}
    recycler = _user(data.get("recycler_id"))
    if recycler is None or recycler["role"] != "recycler":
        return error("valid recycler_id chahiye")

    db = get_db()
    listing = db.execute(
        "SELECT * FROM listings WHERE id = ?", (data.get("listing_id"),)
    ).fetchone()
    if listing is None:
        return error("listing nahi mili", 404)
    if listing["status"] != "open":
        return error("listing pehle hi bik chuki hai", 409)

    rate = db.execute(
        "SELECT price_per_kg FROM rates WHERE recycler_id = ? AND material = ? "
        "ORDER BY id DESC LIMIT 1",
        (recycler["id"], listing["material"]),
    ).fetchone()
    if rate is None:
        return error("is recycler ne is material ka rate set nahi kiya")

    amount = round(listing["weight_kg"] * rate["price_per_kg"], 2)
    cur = db.execute(
        "INSERT INTO transactions (listing_id, collector_id, recycler_id, weight_kg, "
        "price_per_kg, amount, payment_ref) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (
            listing["id"],
            listing["collector_id"],
            recycler["id"],
            listing["weight_kg"],
            rate["price_per_kg"],
            amount,
            data.get("payment_ref"),
        ),
    )
    db.execute("UPDATE listings SET status = 'sold' WHERE id = ?", (listing["id"],))
    db.commit()
    row = db.execute("SELECT * FROM transactions WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201


@bp.get("/transactions")
def list_transactions():
    """Digital record of all deals for one user (collector or recycler)."""
    user = _user(request.args.get("user_id", type=int))
    if user is None:
        return error("valid user_id chahiye")
    rows = get_db().execute(
        "SELECT * FROM transactions WHERE collector_id = ? OR recycler_id = ? ORDER BY id DESC",
        (user["id"], user["id"]),
    ).fetchall()
    return jsonify([dict(r) for r in rows])
