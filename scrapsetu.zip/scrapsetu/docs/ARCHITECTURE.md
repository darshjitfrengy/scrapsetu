# Architecture

## Overview

ScrapSetu ek chhota, simple monolith hai. Ek Flask server REST API aur static web page dono deta hai; data SQLite me rehta hai.

```
 Browser (index.html)  ──HTTP/JSON──▶  Flask app  ──SQL──▶  SQLite
 curl / future mobile app ───────────▶  (app/api.py)         (scrapsetu.sqlite)
```

## Components

| File | Zimmedari |
|---|---|
| `app/__init__.py` | `create_app()` factory: config, DB init, blueprint register |
| `app/api.py` | Saare REST endpoints aur input validation |
| `app/db.py` | SQLite connection (per-request) aur schema |
| `app/static/index.html` | Live rates dikhane wala page |
| `scripts/seed.py` | Sample data load karta hai (API ke through) |

## Data model

- **users**: `id, name, role (collector|recycler), phone (unique), city`
- **rates**: `recycler_id, material, price_per_kg, city`. Har naya rate nayi row hoti hai (history bachti hai); "latest" = sabse bada `id`
- **listings**: `collector_id, material, weight_kg, status (open|sold)`
- **transactions**: `listing_id (unique), collector_id, recycler_id, weight_kg, price_per_kg, amount, payment_ref`

Transaction me weight aur rate **copy** hote hain, taaki baad me rate badalne se purana record na badle.

## Key flow: deal

1. Recycler `POST /api/rates` se rate set karta hai
2. Collector `POST /api/listings` se scrap list karta hai
3. Recycler `POST /api/transactions` call karta hai
4. Server: listing `open` check, recycler ka latest rate nikalta hai, `amount = weight x rate`, transaction insert, listing ko `sold` karta hai (ek hi DB commit me)
5. `listing_id` UNIQUE hone se ek listing do baar nahi bik sakti

## Design decisions

- **SQLite + Flask:** setup zero, hackathon prototype ke liye kaafi. Production me PostgreSQL par move kiya ja sakta hai (SQL simple rakha gaya hai)
- **Rates append-only:** transparency aur audit ke liye
- **Validation server par:** phone (Indian mobile format), material whitelist, positive numbers
- **Frontend me framework nahi:** low-end phones par bhi fast; `textContent` use hota hai taaki XSS na ho

## Security notes

- Prototype me login nahi hai, isliye koi bhi user id bhej sakta hai. Production se pehle OTP + token auth zaroori hai
- Saare SQL parameterised hain (SQL injection se bachav)

## Future

OTP auth, UPI payment gateway, photo upload, Google Maps nearby matching, mobile app (Flutter), rate history charts.
