"""Load data/sample_data.json into the database.

Usage:  python scripts/seed.py
All numbers in the sample file are illustrative, not real market rates.
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from app import create_app  # noqa: E402


def seed(client, data):
    ids = {}
    for u in data["users"]:
        res = client.post("/api/users", json=u)
        if res.status_code == 201:
            ids[u["phone"]] = res.get_json()["id"]
        else:
            print("skip user", u["phone"], res.get_json())
    for r in data["rates"]:
        rid = ids.get(r["recycler_phone"])
        if rid:
            client.post("/api/rates", json={
                "recycler_id": rid, "material": r["material"], "price_per_kg": r["price_per_kg"]})
    for item in data["listings"]:
        cid = ids.get(item["collector_phone"])
        if cid:
            client.post("/api/listings", json={
                "collector_id": cid, "material": item["material"], "weight_kg": item["weight_kg"]})
    return ids


if __name__ == "__main__":
    with open(os.path.join(ROOT, "data", "sample_data.json"), encoding="utf-8") as f:
        sample = json.load(f)
    app = create_app()
    created = seed(app.test_client(), sample)
    print(f"Seeded {len(created)} users.")
