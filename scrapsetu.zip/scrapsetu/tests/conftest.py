import json
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from app import create_app  # noqa: E402


@pytest.fixture()
def client(tmp_path):
    app = create_app({"DATABASE": str(tmp_path / "test.sqlite"), "TESTING": True})
    return app.test_client()


@pytest.fixture()
def sample_data():
    with open(os.path.join(ROOT, "data", "sample_data.json"), encoding="utf-8") as f:
        return json.load(f)


def make_user(client, role, phone, city="Rohtak", name="Test"):
    res = client.post("/api/users", json={"name": name, "role": role, "phone": phone, "city": city})
    assert res.status_code == 201
    return res.get_json()["id"]
