import pytest

from conftest import make_user
from seed import seed


def test_health(client):
    assert client.get("/api/health").get_json() == {"status": "ok"}


def test_home_page_served(client):
    res = client.get("/")
    assert res.status_code == 200
    assert b"ScrapSetu" in res.data


# ---------- users ----------
def test_create_user_ok(client):
    res = client.post("/api/users", json={
        "name": "Ramesh", "role": "collector", "phone": "9876543210", "city": "rohtak"})
    assert res.status_code == 201
    assert res.get_json()["city"] == "Rohtak"


@pytest.mark.parametrize("payload", [
    {"name": "", "role": "collector", "phone": "9876543210", "city": "Rohtak"},
    {"name": "A", "role": "admin", "phone": "9876543210", "city": "Rohtak"},
    {"name": "A", "role": "collector", "phone": "12345", "city": "Rohtak"},
    {"name": "A", "role": "collector", "phone": "9876543210", "city": ""},
])
def test_create_user_validation(client, payload):
    assert client.post("/api/users", json=payload).status_code == 400


def test_duplicate_phone_rejected(client):
    make_user(client, "collector", "9876543210")
    res = client.post("/api/users", json={
        "name": "B", "role": "recycler", "phone": "9876543210", "city": "Rohtak"})
    assert res.status_code == 409


def test_get_missing_user(client):
    assert client.get("/api/users/999").status_code == 404


# ---------- rates ----------
def test_only_recycler_can_set_rate(client):
    collector = make_user(client, "collector", "9876543210")
    res = client.post("/api/rates", json={
        "recycler_id": collector, "material": "copper", "price_per_kg": 700})
    assert res.status_code == 400


def test_rate_validation(client):
    recycler = make_user(client, "recycler", "9876543211")
    bad_material = client.post("/api/rates", json={
        "recycler_id": recycler, "material": "gold", "price_per_kg": 700})
    bad_price = client.post("/api/rates", json={
        "recycler_id": recycler, "material": "copper", "price_per_kg": -5})
    assert bad_material.status_code == 400
    assert bad_price.status_code == 400


def test_rates_show_latest_and_best_first(client):
    r1 = make_user(client, "recycler", "9876543211", name="R1")
    r2 = make_user(client, "recycler", "9876543212", name="R2")
    client.post("/api/rates", json={"recycler_id": r1, "material": "copper", "price_per_kg": 600})
    client.post("/api/rates", json={"recycler_id": r1, "material": "copper", "price_per_kg": 710})
    client.post("/api/rates", json={"recycler_id": r2, "material": "copper", "price_per_kg": 700})
    rates = client.get("/api/rates?material=copper").get_json()
    assert [r["price_per_kg"] for r in rates] == [710, 700]
    assert rates[0]["recycler_name"] == "R1"


# ---------- listings ----------
def test_listing_flow_and_validation(client):
    collector = make_user(client, "collector", "9876543210")
    ok = client.post("/api/listings", json={
        "collector_id": collector, "material": "copper", "weight_kg": 5})
    zero = client.post("/api/listings", json={
        "collector_id": collector, "material": "copper", "weight_kg": 0})
    assert ok.status_code == 201
    assert zero.status_code == 400
    assert len(client.get("/api/listings?city=rohtak").get_json()) == 1


# ---------- transactions ----------
def _setup_deal(client):
    collector = make_user(client, "collector", "9876543210", name="C")
    recycler = make_user(client, "recycler", "9876543211", name="R")
    client.post("/api/rates", json={"recycler_id": recycler, "material": "copper", "price_per_kg": 700})
    listing = client.post("/api/listings", json={
        "collector_id": collector, "material": "copper", "weight_kg": 2.5}).get_json()
    return collector, recycler, listing["id"]


def test_full_deal_creates_record(client):
    collector, recycler, listing_id = _setup_deal(client)
    res = client.post("/api/transactions", json={
        "recycler_id": recycler, "listing_id": listing_id, "payment_ref": "UPI123"})
    assert res.status_code == 201
    deal = res.get_json()
    assert deal["amount"] == 1750.0
    assert deal["payment_ref"] == "UPI123"
    # listing is now sold and both parties see the record
    assert client.get("/api/listings").get_json() == []
    assert len(client.get(f"/api/transactions?user_id={collector}").get_json()) == 1
    assert len(client.get(f"/api/transactions?user_id={recycler}").get_json()) == 1


def test_cannot_buy_same_listing_twice(client):
    _, recycler, listing_id = _setup_deal(client)
    payload = {"recycler_id": recycler, "listing_id": listing_id}
    assert client.post("/api/transactions", json=payload).status_code == 201
    assert client.post("/api/transactions", json=payload).status_code == 409


def test_buy_without_rate_fails(client):
    collector = make_user(client, "collector", "9876543210")
    recycler = make_user(client, "recycler", "9876543211")
    listing = client.post("/api/listings", json={
        "collector_id": collector, "material": "brass", "weight_kg": 3}).get_json()
    res = client.post("/api/transactions", json={
        "recycler_id": recycler, "listing_id": listing["id"]})
    assert res.status_code == 400


def test_buy_missing_listing(client):
    recycler = make_user(client, "recycler", "9876543211")
    res = client.post("/api/transactions", json={"recycler_id": recycler, "listing_id": 99})
    assert res.status_code == 404


# ---------- sample data ----------
def test_sample_data_loads(client, sample_data):
    ids = seed(client, sample_data)
    assert len(ids) == len(sample_data["users"])
    copper = client.get("/api/rates?material=copper").get_json()
    assert copper[0]["price_per_kg"] == 720.0
    assert len(client.get("/api/listings").get_json()) == len(sample_data["listings"])
